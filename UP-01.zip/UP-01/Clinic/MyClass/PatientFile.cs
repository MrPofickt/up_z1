using System;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace Clinic
{
    /// <summary>Самописный класс проверки строк текстового файла пациентов.</summary>
    internal static class PatientFile
    {
        /// <summary>Разбивает запись на шесть полей и проверяет их значения.</summary>
        /// <param name="line">Строка с разделителем «;».</param>
        /// <returns>Поля записи без пробелов по краям.</returns>
        /// <exception cref="FormatException">Неверный формат записи.</exception>
        public static string[] ReadFields(string line)
        {
            string[] fields = line.Split(';');
            if (fields.Length != 6)
                throw new FormatException("В записи должно быть шесть полей, разделённых «;».");

            for (int i = 0; i < fields.Length; i++)
            {
                fields[i] = fields[i].Trim();
                if (fields[i] == "")
                    throw new FormatException("Все поля записи должны быть заполнены.");
            }

            int ticket;
            TimeSpan time;
            DateTime date;
            if (!int.TryParse(fields[0], out ticket) || ticket <= 0)
                throw new FormatException("Номер талона должен быть целым положительным числом.");
            if (!TimeSpan.TryParseExact(fields[1], @"hh\:mm", CultureInfo.InvariantCulture, out time))
                throw new FormatException("Время должно быть записано в формате ЧЧ:мм.");
            if (!DateTime.TryParseExact(fields[3], "dd.MM.yyyy", CultureInfo.InvariantCulture,
                DateTimeStyles.None, out date) ||
                date < DateTimePicker.MinimumDateTime || date > DateTimePicker.MaximumDateTime)
                throw new FormatException("Дата должна быть в формате дд.ММ.гггг, от 01.01.1753 до 31.12.9998.");
            return fields;
        }

        /// <summary>Проверяет файл перед его выбором или изменением.</summary>
        /// <param name="path">Путь к файлу пациентов.</param>
        /// <returns>Количество непустых записей.</returns>
        public static int Validate(string path)
        {
            int count = 0;
            int lineNumber = 0;
            using (StreamReader sr = new StreamReader(path))
            {
                while (!sr.EndOfStream)
                {
                    string s = sr.ReadLine();
                    lineNumber++;
                    if (string.IsNullOrWhiteSpace(s))
                        continue;
                    try
                    {
                        ReadFields(s);
                    }
                    catch (FormatException ex)
                    {
                        throw new FormatException("Ошибка в строке " + lineNumber + ". " + ex.Message, ex);
                    }
                    count++;
                }
            }
            return count;
        }

        /// <summary>Возвращает путь к заранее заполненному файлу-справочнику.</summary>
        /// <param name="name">Имя текстового файла справочника.</param>
        /// <returns>Полный путь относительно каталога приложения.</returns>
        public static string ReferencePath(string name)
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "References", name);
        }
    }
}
