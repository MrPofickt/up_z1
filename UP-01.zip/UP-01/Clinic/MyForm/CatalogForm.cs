using System;
using System.IO;
using System.Windows.Forms;

namespace Clinic
{
    /// <summary>Форма работы со справочником на основе CatalogForm из примера лабораторной.</summary>
    public partial class CatalogForm : Form
    {
        private readonly string fName;

        /// <summary>Создаёт форму в конструкторе Windows Forms.</summary>
        public CatalogForm()
        {
            InitializeComponent();
        }

        /// <summary>Загружает выбранный справочник построчно через StreamReader.</summary>
        /// <param name="title">Название справочника.</param>
        /// <param name="fileName">Путь к текстовому файлу справочника.</param>
        public CatalogForm(string title, string fileName) : this()
        {
            Text = "Справочник: " + title;
            fName = fileName;
            listBox1.Items.Clear();
            using (StreamReader sr = new StreamReader(fName))
            {
                while (!sr.EndOfStream)
                {
                    string s = sr.ReadLine().Trim();
                    if (s != "") listBox1.Items.Add(s);
                }
            }
        }

        /// <summary>Переносит выбранное значение в поле ввода.</summary>
        /// <param name="sender">Список значений справочника.</param>
        /// <param name="e">Аргументы изменения выбора.</param>
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button5.Enabled = button2.Enabled = listBox1.SelectedIndex >= 0;
            if (listBox1.SelectedIndex >= 0)
                textBox2.Text = listBox1.SelectedItem.ToString();
            else
                textBox2.Clear();
        }

        /// <summary>Проверяет новое значение и отсутствие повторов в справочнике.</summary>
        /// <param name="value">Добавляемое или изменённое значение.</param>
        /// <param name="selectedIndex">Индекс изменяемой записи или -1 при добавлении.</param>
        /// <returns>True, если значение можно записать.</returns>
        private bool CheckValue(string value, int selectedIndex)
        {
            if (value == "" || value.IndexOfAny(new[] { ';', '\r', '\n' }) >= 0)
            {
                MessageBox.Show(this, "Введите значение без «;» и перевода строки.");
                return false;
            }
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                if (i != selectedIndex &&
                    string.Equals(listBox1.Items[i].ToString(), value, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show(this, "Такое значение уже есть в справочнике.");
                    return false;
                }
            }
            return true;
        }

        /// <summary>Добавляет новое значение в список, не допуская повторов и разделителей полей.</summary>
        /// <param name="sender">Кнопка добавления.</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void button1_Click(object sender, EventArgs e)
        {
            string value = textBox2.Text.Trim();
            if (!CheckValue(value, -1)) return;
            listBox1.Items.Add(value);
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        /// <summary>Изменяет выбранное значение справочника.</summary>
        /// <param name="sender">Кнопка изменения.</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void button5_Click(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            if (index < 0) return;
            string value = textBox2.Text.Trim();
            if (!CheckValue(value, index)) return;
            listBox1.Items[index] = value;
            textBox2.Text = value;
        }

        /// <summary>Удаляет выбранную запись, не затрагивая остальные значения.</summary>
        /// <param name="sender">Кнопка удаления.</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void button2_Click(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            if (index < 0) return;
            listBox1.Items.RemoveAt(index);
            if (listBox1.Items.Count > 0)
                listBox1.SelectedIndex = Math.Min(index, listBox1.Items.Count - 1);
            // После удаления индекс может не измениться, поэтому обновляем поле и кнопки явно.
            listBox1_SelectedIndexChanged(listBox1, EventArgs.Empty);
        }

        /// <summary>Сохраняет все значения справочника в текстовый файл.</summary>
        /// <param name="sender">Кнопка сохранения.</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string text = "";
                for (int i = 0; i < listBox1.Items.Count; i++)
                    text += listBox1.Items[i].ToString() + "\r\n";
                File.WriteAllText(fName, text);
                MessageBox.Show(this, "Справочник сохранён.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось сохранить справочник");
            }
        }

        /// <summary>Закрывает форму справочника.</summary>
        /// <param name="sender">Кнопка закрытия.</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
