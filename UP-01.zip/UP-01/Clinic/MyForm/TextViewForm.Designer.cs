namespace Clinic
{
    partial class TextViewForm
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>Освобождает компоненты формы просмотра текста.</summary>
        /// <param name="disposing">Нужно ли освободить управляемые ресурсы.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Создаёт многострочное поле для просмотра файла или справочника.</summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TextViewForm));
            this.dataText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // dataText
            this.dataText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataText.Font = new System.Drawing.Font("Consolas", 11F);
            this.dataText.Location = new System.Drawing.Point(0, 0);
            this.dataText.Multiline = true;
            this.dataText.Name = "dataText";
            this.dataText.ReadOnly = true;
            this.dataText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.dataText.Size = new System.Drawing.Size(1000, 450);
            this.dataText.TabIndex = 0;
            this.dataText.WordWrap = false;
            // TextViewForm
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1000, 450);
            this.Controls.Add(this.dataText);
            this.Name = "TextViewForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = resources.GetString("$this.Text");
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox dataText;
    }
}
