using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Clinic
{
    /// <summary>Главная форма: меню работы с текстовым файлом, изображение поликлиники и диаграмма.</summary>
    public partial class MainForm : Form
    {
        private string filePath;

        /// <summary>Создаёт меню, картинку предметной области и элементы выбора года.</summary>
        public MainForm()
        {
            InitializeComponent();
            picture.Image = DrawClinic();
            year.Value = DateTime.Today.Year;
        }

        /// <summary>Включает работу с данными только после выбора или создания файла.</summary>
        /// <param name="available">Выбран ли доступный файл.</param>
        private void SetFileAvailable(bool available)
        {
            viewMenu.Enabled = editMenu.Enabled = clearItem.Enabled = draw.Enabled = year.Enabled = available;
        }

        /// <summary>Выбирает созданный или проверенный файл и очищает старую диаграмму.</summary>
        /// <param name="path">Путь к файлу пациентов.</param>
        private void SelectFile(string path)
        {
            filePath = path;
            fileLabel.Text = "Выбран файл: " + path;
            SetFileAvailable(true);
            chart.Series[0].Points.Clear();
            chart.Titles[0].Text = "Пациенты по сезонам указанного года";
        }

        /// <summary>Создаёт пустой файл через SaveFileDialog с закрытием потока File.Create.</summary>
        /// <param name="sender">Пункт «Создать».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void CreateClick(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog(this) != DialogResult.OK) return;
            try
            {
                File.Create(saveFileDialog1.FileName).Close();
                SelectFile(saveFileDialog1.FileName);
                MessageBox.Show(this, "Файл создан.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось создать файл");
            }
        }

        /// <summary>Открывает существующий файл через OpenFileDialog после проверки его записей.</summary>
        /// <param name="sender">Пункт «Выбрать».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void OpenClick(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog(this) != DialogResult.OK) return;
            try
            {
                PatientFile.Validate(openFileDialog1.FileName);
                SelectFile(openFileDialog1.FileName);
                MessageBox.Show(this, "Файл открыт.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось открыть файл");
            }
        }

        /// <summary>Очищает выбранный файл только после подтверждения пользователя.</summary>
        /// <param name="sender">Пункт «Очистить».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void ClearClick(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Удалить все записи из выбранного файла?", "Очистка", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                File.Create(filePath).Close();
                chart.Series[0].Points.Clear();
                chart.Titles[0].Text = "Пациенты по сезонам указанного года";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось очистить файл");
            }
        }

        /// <summary>Выводит все данные пациентов в многострочный TextBox отдельного окна.</summary>
        /// <param name="sender">Пункт «Всех данных».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void ViewAllClick(object sender, EventArgs e)
        {
            try
            {
                string text = "Номер талона; Время; ФИО пациента; Дата обращения; ФИО врача; Специализация\r\n";
                int count = 0;
                using (StreamReader sr = new StreamReader(filePath))
                {
                    while (!sr.EndOfStream)
                    {
                        string s = sr.ReadLine();
                        if (string.IsNullOrWhiteSpace(s)) continue;
                        PatientFile.ReadFields(s);
                        text += s + "\r\n";
                        count++;
                    }
                }
                if (count == 0) text += "Нет записей";
                using (TextViewForm form = new TextViewForm("Все данные пациентов", text))
                    form.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось прочитать файл");
            }
        }

        /// <summary>Открывает просмотр по трём условиям индивидуального задания.</summary>
        /// <param name="sender">Пункт «По условию».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void FilterClick(object sender, EventArgs e)
        {
            try
            {
                using (FilterForm form = new FilterForm(filePath))
                    form.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось открыть просмотр");
            }
        }

        /// <summary>Открывает форму добавления записи пациента.</summary>
        /// <param name="sender">Пункт «Добавление».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void AddClick(object sender, EventArgs e)
        {
            try
            {
                using (RecordForm form = new RecordForm(filePath, false))
                {
                    if (form.ShowDialog(this) == DialogResult.OK)
                    {
                        chart.Series[0].Points.Clear();
                        chart.Titles[0].Text = "Пациенты по сезонам указанного года";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось открыть добавление");
            }
        }

        /// <summary>Открывает форму выбора и изменения существующей записи.</summary>
        /// <param name="sender">Пункт «Редактирование».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void EditClick(object sender, EventArgs e)
        {
            try
            {
                if (PatientFile.Validate(filePath) == 0)
                {
                    MessageBox.Show(this, "Файл пуст. Сначала добавьте запись.");
                    return;
                }
                using (RecordForm form = new RecordForm(filePath, true))
                {
                    if (form.ShowDialog(this) == DialogResult.OK)
                    {
                        chart.Series[0].Points.Clear();
                        chart.Titles[0].Text = "Пациенты по сезонам указанного года";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось открыть редактирование");
            }
        }

        /// <summary>Открывает редактирование справочника врачей.</summary>
        /// <param name="sender">Пункт «Врачи».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void DoctorsClick(object sender, EventArgs e)
        {
            ShowReference("Врачи", "Doctors.txt");
        }

        /// <summary>Открывает редактирование справочника специализаций.</summary>
        /// <param name="sender">Пункт «Специализации».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void SpecializationsClick(object sender, EventArgs e)
        {
            ShowReference("Специализации", "Specializations.txt");
        }

        /// <summary>Открывает форму работы со справочником, как в примере лабораторной.</summary>
        /// <param name="title">Заголовок справочника.</param>
        /// <param name="name">Имя файла справочника.</param>
        private void ShowReference(string title, string name)
        {
            try
            {
                using (CatalogForm form = new CatalogForm(title, PatientFile.ReferencePath(name)))
                    form.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось открыть справочник");
            }
        }

        /// <summary>Считает обращения за каждый сезон выбранного календарного года и строит круговую диаграмму.</summary>
        /// <param name="sender">Кнопка построения диаграммы.</param>
        /// <param name="e">Аргументы нажатия.</param>
        /// <remarks>Зима — январь, февраль и декабрь указанного года; остальные сезоны — по три следующих месяца.</remarks>
        private void DrawClick(object sender, EventArgs e)
        {
            try
            {
                int[] season = new int[4];
                using (StreamReader sr = new StreamReader(filePath))
                {
                    while (!sr.EndOfStream)
                    {
                        string s = sr.ReadLine();
                        if (string.IsNullOrWhiteSpace(s)) continue;
                        string[] fields = PatientFile.ReadFields(s);
                        DateTime date = DateTime.ParseExact(fields[3], "dd.MM.yyyy",
                            System.Globalization.CultureInfo.InvariantCulture);
                        if (date.Year == year.Value)
                        {
                            int month = date.Month;
                            if (month == 12 || month <= 2) season[0]++;
                            else if (month <= 5) season[1]++;
                            else if (month <= 8) season[2]++;
                            else season[3]++;
                        }
                    }
                }
                string[] seasons = { "Зима", "Весна", "Лето", "Осень" };
                chart.Series[0].Points.Clear();
                int count = 0;
                for (int i = 0; i < 4; i++)
                {
                    chart.Series[0].Points.AddXY(seasons[i], season[i]);
                    count += season[i];
                }
                if (count == 0) chart.Titles[0].Text = "За " + year.Value + " год обращений нет";
                else chart.Titles[0].Text = "Обращения пациентов за " + year.Value + " год";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось построить диаграмму");
            }
        }

        /// <summary>Создаёт картинку поликлиники для главной формы.</summary>
        /// <returns>Растровое изображение медицинского здания с красным крестом.</returns>
        private static Bitmap DrawClinic()
        {
            Bitmap image = new Bitmap(350, 360);
            using (Graphics g = Graphics.FromImage(image))
            using (SolidBrush wall = new SolidBrush(Color.WhiteSmoke))
            using (SolidBrush window = new SolidBrush(Color.LightSkyBlue))
            using (SolidBrush red = new SolidBrush(Color.Firebrick))
            using (SolidBrush ink = new SolidBrush(Color.MidnightBlue))
            using (Font font = new Font("Segoe UI", 19, FontStyle.Bold))
            {
                g.Clear(Color.AliceBlue);
                g.FillRectangle(wall, 25, 75, 300, 245);
                g.DrawRectangle(Pens.SlateGray, 25, 75, 300, 245);
                g.FillRectangle(red, 162, 16, 26, 70);
                g.FillRectangle(red, 140, 38, 70, 26);
                g.DrawString("ПОЛИКЛИНИКА", font, ink, 55, 92);
                for (int x = 48; x <= 258; x += 70)
                    for (int y = 150; y <= 210; y += 60)
                        g.FillRectangle(window, x, y, 40, 35);
                g.FillRectangle(ink, 145, 265, 60, 55);
                g.DrawLine(Pens.White, 175, 265, 175, 320);
                g.FillRectangle(Brushes.DarkSeaGreen, 0, 321, 350, 39);
            }
            return image;
        }

        /// <summary>Закрывает приложение.</summary>
        /// <param name="sender">Пункт «Выход».</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void ExitClick(object sender, EventArgs e)
        {
            Close();
        }

    }
}
