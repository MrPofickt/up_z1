using System.Windows.Forms;

namespace Clinic
{
    /// <summary>Выводит содержимое файла или результат отбора в многострочном TextBox.</summary>
    public partial class TextViewForm : Form
    {
        /// <summary>Создаёт многострочное поле просмотра в конструкторе Windows Forms.</summary>
        public TextViewForm()
        {
            InitializeComponent();
        }

        /// <summary>Создаёт окно просмотра переданного текста.</summary>
        /// <param name="title">Заголовок окна.</param>
        /// <param name="text">Данные для просмотра.</param>
        public TextViewForm(string title, string text) : this()
        {
            Text = title;
            dataText.Text = text;
        }
    }
}
