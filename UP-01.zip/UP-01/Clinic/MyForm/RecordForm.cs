using System;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace Clinic
{
    /// <summary>Форма добавления или редактирования записи пациента.</summary>
    public partial class RecordForm : Form
    {
        private readonly string path;
        private readonly bool editing;
        private string[] lines;
        private int[] lineNumbers;

        /// <summary>Создаёт форму в конструкторе Windows Forms без обращения к файлам.</summary>
        public RecordForm()
        {
            InitializeComponent();
        }

        /// <summary>Загружает файл пациентов и заполняет ComboBox строками справочников через AddRange.</summary>
        /// <param name="filePath">Путь к выбранному файлу пациентов.</param>
        /// <param name="edit">True для редактирования, false для добавления.</param>
        public RecordForm(string filePath, bool edit) : this()
        {
            path = filePath;
            editing = edit;
            PatientFile.Validate(path);
            Text = editing ? "Редактирование пациента" : "Добавление пациента";
            selection.Enabled = editing;
            doctor.Items.Clear();
            doctor.Items.AddRange(File.ReadAllLines(PatientFile.ReferencePath("Doctors.txt")));
            specialization.Items.Clear();
            specialization.Items.AddRange(File.ReadAllLines(PatientFile.ReferencePath("Specializations.txt")));
            if (doctor.Items.Count > 0) doctor.SelectedIndex = 0;
            if (specialization.Items.Count > 0) specialization.SelectedIndex = 0;

            if (editing)
            {
                lines = File.ReadAllLines(path);
                lineNumbers = new int[lines.Length];
                for (int i = 0; i < lines.Length; i++)
                {
                    if (string.IsNullOrWhiteSpace(lines[i])) continue;
                    lineNumbers[selection.Items.Count] = i;
                    selection.Items.Add(lines[i]);
                }
                if (selection.Items.Count > 0) selection.SelectedIndex = 0;
                else save.Enabled = false;
            }
        }

        /// <summary>Извлекает данные записи в поля формы по образцу ExtractFields из EditForm.</summary>
        /// <param name="s">Выбранная строка текстового файла.</param>
        private void ExtractFields(string s)
        {
            string[] fields = PatientFile.ReadFields(s);
            ticket.Value = int.Parse(fields[0]);
            time.Value = DateTime.Today.Add(TimeSpan.ParseExact(fields[1], @"hh\:mm", CultureInfo.InvariantCulture));
            patient.Text = fields[2];
            date.Value = DateTime.ParseExact(fields[3], "dd.MM.yyyy", CultureInfo.InvariantCulture);
            // Старые значения сохраняются даже после изменения справочника.
            if (!doctor.Items.Contains(fields[4])) doctor.Items.Add(fields[4]);
            if (!specialization.Items.Contains(fields[5])) specialization.Items.Add(fields[5]);
            doctor.SelectedItem = fields[4];
            specialization.SelectedItem = fields[5];
        }

        /// <summary>Переносит выбранную запись в поля редактирования.</summary>
        /// <param name="sender">Список записей.</param>
        /// <param name="e">Аргументы изменения выбора.</param>
        private void SelectionChanged(object sender, EventArgs e)
        {
            if (selection.SelectedIndex < 0) return;
            ExtractFields(lines[lineNumbers[selection.SelectedIndex]]);
        }

        /// <summary>Проверяет поля и сохраняет добавленную или изменённую запись.</summary>
        /// <param name="sender">Кнопка сохранения.</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void SaveClick(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(patient.Text) || doctor.SelectedIndex < 0 || specialization.SelectedIndex < 0 ||
                patient.Text.IndexOfAny(new[] { ';', '\r', '\n' }) >= 0)
            {
                MessageBox.Show(this, "Заполните все поля. ФИО пациента не должно содержать «;» или перевод строки.");
                return;
            }
            try
            {
                // Формат записи такой же, как в AddRecord и EditForm примера.
                string sEdit = $"{ticket.Value}; {time.Value:HH:mm}; {patient.Text.Trim()}; " +
                    $"{date.Value:dd.MM.yyyy}; {doctor.Text.Trim()}; {specialization.Text.Trim()}";
                PatientFile.ReadFields(sEdit);
                PatientFile.Validate(path);
                if (editing)
                {
                    if (selection.SelectedIndex < 0)
                        return;
                    string[] currentLines = File.ReadAllLines(path);
                    if (currentLines.Length != lines.Length)
                        throw new IOException("Файл изменился. Закройте окно и выберите запись заново.");
                    for (int i = 0; i < lines.Length; i++)
                    {
                        if (currentLines[i] != lines[i])
                            throw new IOException("Файл изменился. Закройте окно и выберите запись заново.");
                    }
                    // Изменяем только выбранную строку: Replace заменил бы все одинаковые записи.
                    currentLines[lineNumbers[selection.SelectedIndex]] = sEdit;
                    File.WriteAllLines(path, currentLines);
                }
                else
                {
                    string fileContent = File.ReadAllText(path);
                    string separator = "";
                    if (fileContent.Length > 0 &&
                        fileContent[fileContent.Length - 1] != '\n' && fileContent[fileContent.Length - 1] != '\r')
                        separator = Environment.NewLine;
                    File.AppendAllText(path, separator + sEdit + Environment.NewLine);
                }
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось сохранить", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
