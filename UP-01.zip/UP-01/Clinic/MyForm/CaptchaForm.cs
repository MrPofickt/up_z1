using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Clinic
{
    /// <summary>Стартовая форма проверки кода с изображения.</summary>
    public partial class CaptchaForm : Form
    {
        private readonly Random random = new Random();
        private string code;

        /// <summary>Создаёт поле ввода, изображение капчи и кнопки проверки и обновления.</summary>
        public CaptchaForm()
        {
            InitializeComponent();
            GenerateCaptcha();
        }

        /// <summary>Генерирует три буквы и три цифры на разных уровнях, перечёркнутые линиями.</summary>
        private void GenerateCaptcha()
        {
            const string letters = "ABCDEFGHJKLMNPQRSTUVWXYZ";
            const string digits = "23456789";
            char[] symbols = new char[6];
            for (int i = 0; i < symbols.Length; i++)
                symbols[i] = i % 2 == 0 ? letters[random.Next(letters.Length)] : digits[random.Next(digits.Length)];
            code = new string(symbols);
            Bitmap image = new Bitmap(350, 90);
            using (Graphics g = Graphics.FromImage(image))
            using (Font font = new Font("Georgia", 29, FontStyle.Bold))
            using (SolidBrush brush = new SolidBrush(Color.MidnightBlue))
            using (Pen pen = new Pen(Color.SlateGray, 2))
            {
                g.Clear(Color.AliceBlue);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                for (int i = 0; i < symbols.Length; i++)
                {
                    int x = 15 + i * 54;
                    int y = (i % 2 == 0 ? 8 : 29) + random.Next(5);
                    g.DrawString(symbols[i].ToString(), font, brush, x, y);
                    g.DrawLine(pen, x, y + 25, x + 40, y + 17);
                }
                g.DrawLine(pen, 0, 58, 350, 24);
                g.DrawLine(pen, 0, 27, 350, 66);
            }
            Image old = picture.Image;
            picture.Image = image;
            if (old != null) old.Dispose();
            input.Clear();
            input.Focus();
        }

        /// <summary>Сравнивает введённый код с изображением без учёта регистра.</summary>
        /// <param name="sender">Кнопка входа.</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void VerifyClick(object sender, EventArgs e)
        {
            if (string.Equals(input.Text.Trim(), code, StringComparison.OrdinalIgnoreCase))
            {
                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                MessageBox.Show(this, "Неверный код. Попробуйте ещё раз.", "CAPTCHA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                GenerateCaptcha();
            }
        }

        /// <summary>Заменяет изображение капчи новым кодом.</summary>
        /// <param name="sender">Кнопка обновления.</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void RefreshClick(object sender, EventArgs e)
        {
            GenerateCaptcha();
        }

    }
}
