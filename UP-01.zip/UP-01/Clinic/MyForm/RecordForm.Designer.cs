namespace Clinic
{
    partial class RecordForm
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>Освобождает компоненты формы добавления и редактирования.</summary>
        /// <param name="disposing">Нужно ли освободить управляемые ресурсы.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Создаёт подписи, поля записи и кнопки сохранения и отмены.</summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RecordForm));
            this.selectionLabel = new System.Windows.Forms.Label();
            this.ticketLabel = new System.Windows.Forms.Label();
            this.timeLabel = new System.Windows.Forms.Label();
            this.patientLabel = new System.Windows.Forms.Label();
            this.dateLabel = new System.Windows.Forms.Label();
            this.doctorLabel = new System.Windows.Forms.Label();
            this.specializationLabel = new System.Windows.Forms.Label();
            this.selection = new System.Windows.Forms.ComboBox();
            this.ticket = new System.Windows.Forms.NumericUpDown();
            this.time = new System.Windows.Forms.DateTimePicker();
            this.patient = new System.Windows.Forms.TextBox();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.doctor = new System.Windows.Forms.ComboBox();
            this.specialization = new System.Windows.Forms.ComboBox();
            this.save = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ticket)).BeginInit();
            this.SuspendLayout();
            // selectionLabel
            this.selectionLabel.Location = new System.Drawing.Point(18, 22);
            this.selectionLabel.Name = "selectionLabel";
            this.selectionLabel.Size = new System.Drawing.Size(190, 23);
            this.selectionLabel.Text = "Запись для изменения";
            // ticketLabel
            this.ticketLabel.Location = new System.Drawing.Point(18, 69);
            this.ticketLabel.Name = "ticketLabel";
            this.ticketLabel.Size = new System.Drawing.Size(190, 23);
            this.ticketLabel.Text = "Номер талона";
            // timeLabel
            this.timeLabel.Location = new System.Drawing.Point(18, 116);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Size = new System.Drawing.Size(190, 23);
            this.timeLabel.Text = "Время";
            // patientLabel
            this.patientLabel.Location = new System.Drawing.Point(18, 163);
            this.patientLabel.Name = "patientLabel";
            this.patientLabel.Size = new System.Drawing.Size(190, 23);
            this.patientLabel.Text = "ФИО пациента";
            // dateLabel
            this.dateLabel.Location = new System.Drawing.Point(18, 210);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(190, 23);
            this.dateLabel.Text = "Дата обращения";
            // doctorLabel
            this.doctorLabel.Location = new System.Drawing.Point(18, 257);
            this.doctorLabel.Name = "doctorLabel";
            this.doctorLabel.Size = new System.Drawing.Size(190, 23);
            this.doctorLabel.Text = "ФИО врача";
            // specializationLabel
            this.specializationLabel.Location = new System.Drawing.Point(18, 304);
            this.specializationLabel.Name = "specializationLabel";
            this.specializationLabel.Size = new System.Drawing.Size(190, 23);
            this.specializationLabel.Text = "Специализация врача";
            // selection
            this.selection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selection.Enabled = false;
            this.selection.Location = new System.Drawing.Point(215, 18);
            this.selection.Name = "selection";
            this.selection.Size = new System.Drawing.Size(430, 28);
            this.selection.TabIndex = 0;
            this.selection.SelectedIndexChanged += new System.EventHandler(this.SelectionChanged);
            // ticket
            this.ticket.Location = new System.Drawing.Point(215, 65);
            this.ticket.Maximum = new decimal(new int[] { 2147483647, 0, 0, 0 });
            this.ticket.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.ticket.Name = "ticket";
            this.ticket.Size = new System.Drawing.Size(430, 28);
            this.ticket.TabIndex = 1;
            this.ticket.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // time
            this.time.CustomFormat = "HH:mm";
            this.time.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.time.Location = new System.Drawing.Point(215, 112);
            this.time.Name = "time";
            this.time.ShowUpDown = true;
            this.time.Size = new System.Drawing.Size(430, 28);
            this.time.TabIndex = 2;
            // patient
            this.patient.Location = new System.Drawing.Point(215, 159);
            this.patient.Name = "patient";
            this.patient.Size = new System.Drawing.Size(430, 28);
            this.patient.TabIndex = 3;
            // date
            this.date.CustomFormat = "dd.MM.yyyy";
            this.date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date.Location = new System.Drawing.Point(215, 206);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(430, 28);
            this.date.TabIndex = 4;
            // doctor
            this.doctor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.doctor.Location = new System.Drawing.Point(215, 253);
            this.doctor.Name = "doctor";
            this.doctor.Size = new System.Drawing.Size(430, 28);
            this.doctor.TabIndex = 5;
            // specialization
            this.specialization.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.specialization.Location = new System.Drawing.Point(215, 300);
            this.specialization.Name = "specialization";
            this.specialization.Size = new System.Drawing.Size(430, 28);
            this.specialization.TabIndex = 6;
            // save
            this.save.Location = new System.Drawing.Point(370, 356);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(130, 32);
            this.save.TabIndex = 7;
            this.save.Text = "Сохранить";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.SaveClick);
            // cancel
            this.cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancel.Location = new System.Drawing.Point(515, 356);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(130, 32);
            this.cancel.TabIndex = 8;
            this.cancel.Text = "Отмена";
            this.cancel.UseVisualStyleBackColor = true;
            // RecordForm
            this.AcceptButton = this.save;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.cancel;
            this.ClientSize = new System.Drawing.Size(670, 405);
            this.Controls.Add(this.selectionLabel);
            this.Controls.Add(this.ticketLabel);
            this.Controls.Add(this.timeLabel);
            this.Controls.Add(this.patientLabel);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.doctorLabel);
            this.Controls.Add(this.specializationLabel);
            this.Controls.Add(this.selection);
            this.Controls.Add(this.ticket);
            this.Controls.Add(this.time);
            this.Controls.Add(this.patient);
            this.Controls.Add(this.date);
            this.Controls.Add(this.doctor);
            this.Controls.Add(this.specialization);
            this.Controls.Add(this.save);
            this.Controls.Add(this.cancel);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "RecordForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = resources.GetString("$this.Text");
            ((System.ComponentModel.ISupportInitialize)(this.ticket)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label selectionLabel;
        private System.Windows.Forms.Label ticketLabel;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Label patientLabel;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.Label doctorLabel;
        private System.Windows.Forms.Label specializationLabel;
        private System.Windows.Forms.ComboBox selection;
        private System.Windows.Forms.NumericUpDown ticket;
        private System.Windows.Forms.DateTimePicker time;
        private System.Windows.Forms.TextBox patient;
        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.ComboBox doctor;
        private System.Windows.Forms.ComboBox specialization;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button cancel;
    }
}
