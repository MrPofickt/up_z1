namespace Clinic
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>Освобождает диалоги, изображение поликлиники и компоненты формы.</summary>
        /// <param name="disposing">Нужно ли освободить управляемые ресурсы.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                saveFileDialog1.Dispose();
                openFileDialog1.Dispose();
                if (picture.Image != null)
                {
                    picture.Image.Dispose();
                    picture.Image = null;
                }
                if (components != null) components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Создаёт меню, диалоги, элементы выбора года, PictureBox и круговую диаграмму.</summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.createItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filterItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.addItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editItem = new System.Windows.Forms.ToolStripMenuItem();
            this.referencesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.doctorsItem = new System.Windows.Forms.ToolStripMenuItem();
            this.specializationsItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.fileLabel = new System.Windows.Forms.Label();
            this.picture = new System.Windows.Forms.PictureBox();
            this.yearLabel = new System.Windows.Forms.Label();
            this.year = new System.Windows.Forms.NumericUpDown();
            this.draw = new System.Windows.Forms.Button();
            this.chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.year)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart)).BeginInit();
            this.SuspendLayout();
            // menuStrip
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.fileMenu, this.viewMenu, this.editMenu, this.referencesMenu, this.exitItem });
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1060, 24);
            this.menuStrip.TabIndex = 0;
            // fileMenu
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.createItem, this.openItem, this.clearItem });
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Text = "Файл";
            // createItem
            this.createItem.Name = "createItem";
            this.createItem.Text = "Создать";
            this.createItem.Click += new System.EventHandler(this.CreateClick);
            // openItem
            this.openItem.Name = "openItem";
            this.openItem.Text = "Выбрать";
            this.openItem.Click += new System.EventHandler(this.OpenClick);
            // clearItem
            this.clearItem.Enabled = false;
            this.clearItem.Name = "clearItem";
            this.clearItem.Text = "Очистить";
            this.clearItem.Click += new System.EventHandler(this.ClearClick);
            // viewMenu
            this.viewMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.viewAllItem, this.filterItem });
            this.viewMenu.Enabled = false;
            this.viewMenu.Name = "viewMenu";
            this.viewMenu.Text = "Просмотр";
            // viewAllItem
            this.viewAllItem.Name = "viewAllItem";
            this.viewAllItem.Text = "Всех данных";
            this.viewAllItem.Click += new System.EventHandler(this.ViewAllClick);
            // filterItem
            this.filterItem.Name = "filterItem";
            this.filterItem.Text = "По условию";
            this.filterItem.Click += new System.EventHandler(this.FilterClick);
            // editMenu
            this.editMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.addItem, this.editItem });
            this.editMenu.Enabled = false;
            this.editMenu.Name = "editMenu";
            this.editMenu.Text = "Редактирование";
            // addItem
            this.addItem.Name = "addItem";
            this.addItem.Text = "Добавление";
            this.addItem.Click += new System.EventHandler(this.AddClick);
            // editItem
            this.editItem.Name = "editItem";
            this.editItem.Text = "Редактирование";
            this.editItem.Click += new System.EventHandler(this.EditClick);
            // referencesMenu
            this.referencesMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.doctorsItem, this.specializationsItem });
            this.referencesMenu.Name = "referencesMenu";
            this.referencesMenu.Text = "Справочники";
            // doctorsItem
            this.doctorsItem.Name = "doctorsItem";
            this.doctorsItem.Text = "Врачи";
            this.doctorsItem.Click += new System.EventHandler(this.DoctorsClick);
            // specializationsItem
            this.specializationsItem.Name = "specializationsItem";
            this.specializationsItem.Text = "Специализации";
            this.specializationsItem.Click += new System.EventHandler(this.SpecializationsClick);
            // exitItem
            this.exitItem.Name = "exitItem";
            this.exitItem.Text = "Выход";
            this.exitItem.Click += new System.EventHandler(this.ExitClick);
            // saveFileDialog1
            this.saveFileDialog1.DefaultExt = "txt";
            this.saveFileDialog1.Filter = "Текстовые файлы (*.txt)|*.txt";
            // openFileDialog1
            this.openFileDialog1.Filter = "Текстовые файлы (*.txt)|*.txt";
            // fileLabel
            this.fileLabel.Location = new System.Drawing.Point(20, 45);
            this.fileLabel.Name = "fileLabel";
            this.fileLabel.Size = new System.Drawing.Size(1020, 48);
            this.fileLabel.Text = "Файл не выбран. Используйте меню «Файл».";
            // picture
            this.picture.Location = new System.Drawing.Point(20, 120);
            this.picture.Name = "picture";
            this.picture.Size = new System.Drawing.Size(350, 360);
            this.picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picture.TabStop = false;
            // yearLabel
            this.yearLabel.Location = new System.Drawing.Point(400, 103);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(45, 23);
            this.yearLabel.Text = "Год:";
            // year
            this.year.Enabled = false;
            this.year.Location = new System.Drawing.Point(450, 99);
            this.year.Maximum = new decimal(new int[] { 9999, 0, 0, 0 });
            this.year.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(100, 28);
            this.year.TabIndex = 1;
            this.year.Value = new decimal(new int[] { 2026, 0, 0, 0 });
            // draw
            this.draw.Enabled = false;
            this.draw.Location = new System.Drawing.Point(575, 97);
            this.draw.Name = "draw";
            this.draw.Size = new System.Drawing.Size(220, 34);
            this.draw.TabIndex = 2;
            this.draw.Text = "Показать диаграмму";
            this.draw.UseVisualStyleBackColor = true;
            this.draw.Click += new System.EventHandler(this.DrawClick);
            // chart
            this.chart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.Name = "Seasons";
            this.chart.ChartAreas.Add(chartArea1);
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Right;
            legend1.Name = "Seasons";
            this.chart.Legends.Add(legend1);
            this.chart.Location = new System.Drawing.Point(395, 150);
            this.chart.Name = "chart";
            series1.ChartArea = "Seasons";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.IsValueShownAsLabel = true;
            series1.Label = "#VALY";
            series1.Legend = "Seasons";
            series1.LegendText = "#AXISLABEL: #VALY";
            series1.Name = "Пациенты";
            series1.ToolTip = "#AXISLABEL: #VALY пациентов";
            this.chart.Series.Add(series1);
            this.chart.Size = new System.Drawing.Size(640, 375);
            this.chart.TabIndex = 3;
            title1.Text = "Пациенты по сезонам указанного года";
            this.chart.Titles.Add(title1);
            // MainForm
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1060, 570);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.fileLabel);
            this.Controls.Add(this.picture);
            this.Controls.Add(this.yearLabel);
            this.Controls.Add(this.year);
            this.Controls.Add(this.draw);
            this.Controls.Add(this.chart);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.MainMenuStrip = this.menuStrip;
            this.MinimumSize = new System.Drawing.Size(1076, 609);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = resources.GetString("$this.Text");
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.year)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem createItem;
        private System.Windows.Forms.ToolStripMenuItem openItem;
        private System.Windows.Forms.ToolStripMenuItem clearItem;
        private System.Windows.Forms.ToolStripMenuItem viewMenu;
        private System.Windows.Forms.ToolStripMenuItem viewAllItem;
        private System.Windows.Forms.ToolStripMenuItem filterItem;
        private System.Windows.Forms.ToolStripMenuItem editMenu;
        private System.Windows.Forms.ToolStripMenuItem addItem;
        private System.Windows.Forms.ToolStripMenuItem editItem;
        private System.Windows.Forms.ToolStripMenuItem referencesMenu;
        private System.Windows.Forms.ToolStripMenuItem doctorsItem;
        private System.Windows.Forms.ToolStripMenuItem specializationsItem;
        private System.Windows.Forms.ToolStripMenuItem exitItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label fileLabel;
        private System.Windows.Forms.PictureBox picture;
        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.NumericUpDown year;
        private System.Windows.Forms.Button draw;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart;
    }
}
