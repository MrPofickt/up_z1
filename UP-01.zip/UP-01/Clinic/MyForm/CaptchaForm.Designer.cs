namespace Clinic
{
    partial class CaptchaForm
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>Освобождает изображение капчи, компоненты и элементы формы.</summary>
        /// <param name="disposing">Нужно ли освободить управляемые ресурсы.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (picture.Image != null)
                {
                    picture.Image.Dispose();
                    picture.Image = null;
                }
                if (components != null) components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Создаёт элементы формы, задаёт их свойства и подключает обработчики событий.</summary>
        private void InitializeComponent()
        {
            this.instructionLabel = new System.Windows.Forms.Label();
            this.picture = new System.Windows.Forms.PictureBox();
            this.input = new System.Windows.Forms.TextBox();
            this.verify = new System.Windows.Forms.Button();
            this.refresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).BeginInit();
            this.SuspendLayout();
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(18, 16);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(282, 19);
            this.instructionLabel.TabIndex = 0;
            this.instructionLabel.Text = "Введите код с картинки (латинские буквы):";
            // 
            // picture
            // 
            this.picture.Location = new System.Drawing.Point(20, 46);
            this.picture.Name = "picture";
            this.picture.Size = new System.Drawing.Size(350, 90);
            this.picture.TabIndex = 1;
            this.picture.TabStop = false;
            // 
            // input
            // 
            this.input.Location = new System.Drawing.Point(20, 150);
            this.input.MaxLength = 6;
            this.input.Name = "input";
            this.input.Size = new System.Drawing.Size(350, 25);
            this.input.TabIndex = 0;
            // 
            // verify
            // 
            this.verify.Location = new System.Drawing.Point(20, 194);
            this.verify.Name = "verify";
            this.verify.Size = new System.Drawing.Size(165, 32);
            this.verify.TabIndex = 1;
            this.verify.Text = "Войти";
            this.verify.UseVisualStyleBackColor = true;
            this.verify.Click += new System.EventHandler(this.VerifyClick);
            // 
            // refresh
            // 
            this.refresh.Location = new System.Drawing.Point(205, 194);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(165, 32);
            this.refresh.TabIndex = 2;
            this.refresh.Text = "Другой код";
            this.refresh.UseVisualStyleBackColor = true;
            this.refresh.Click += new System.EventHandler(this.RefreshClick);
            // 
            // CaptchaForm
            // 
            this.AcceptButton = this.verify;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(390, 245);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.picture);
            this.Controls.Add(this.input);
            this.Controls.Add(this.verify);
            this.Controls.Add(this.refresh);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "CaptchaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Проверка CAPTCHA";
            ((System.ComponentModel.ISupportInitialize)(this.picture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.PictureBox picture;
        private System.Windows.Forms.TextBox input;
        private System.Windows.Forms.Button verify;
        private System.Windows.Forms.Button refresh;
    }
}
