using System;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace Clinic
{
    /// <summary>Просмотр пациентов по специализации, дате или сочетанию специализации и ФИО врача.</summary>
    public partial class FilterForm : Form
    {
        private readonly string path;

        /// <summary>Создаёт форму в конструкторе Windows Forms без чтения файлов.</summary>
        public FilterForm()
        {
            InitializeComponent();
            mode.SelectedIndex = 0;
        }

        /// <summary>Создаёт три предусмотренных заданием варианта отбора.</summary>
        /// <param name="filePath">Путь к выбранному файлу пациентов.</param>
        public FilterForm(string filePath) : this()
        {
            path = filePath;
            PatientFile.Validate(path);
            specialization.Items.Clear();
            specialization.Items.AddRange(File.ReadAllLines(PatientFile.ReferencePath("Specializations.txt")));
            doctor.Items.Clear();
            doctor.Items.AddRange(File.ReadAllLines(PatientFile.ReferencePath("Doctors.txt")));
            using (StreamReader sr = new StreamReader(path))
            {
                while (!sr.EndOfStream)
                {
                    string s = sr.ReadLine();
                    if (string.IsNullOrWhiteSpace(s)) continue;
                    string[] fields = PatientFile.ReadFields(s);
                    if (!specialization.Items.Contains(fields[5])) specialization.Items.Add(fields[5]);
                    if (!doctor.Items.Contains(fields[4])) doctor.Items.Add(fields[4]);
                }
            }
            if (specialization.Items.Count > 0) specialization.SelectedIndex = 0;
            if (doctor.Items.Count > 0) doctor.SelectedIndex = 0;
        }

        /// <summary>Включает только поля, необходимые для выбранного условия.</summary>
        /// <param name="sender">Список условий.</param>
        /// <param name="e">Аргументы изменения выбора.</param>
        private void ModeChanged(object sender, EventArgs e)
        {
            specialization.Enabled = mode.SelectedIndex != 1;
            date.Enabled = mode.SelectedIndex == 1;
            doctor.Enabled = mode.SelectedIndex == 2;
            result.Clear();
        }

        /// <summary>Отбирает записи по выбранному условию и выводит их в многострочное поле.</summary>
        /// <param name="sender">Кнопка просмотра.</param>
        /// <param name="e">Аргументы нажатия.</param>
        private void ShowClick(object sender, EventArgs e)
        {
            try
            {
                string text = "Номер талона; Время; ФИО пациента; Дата обращения; ФИО врача; Специализация\r\n";
                int count = 0;
                using (StreamReader sr = new StreamReader(path))
                {
                    while (!sr.EndOfStream)
                    {
                        string s = sr.ReadLine();
                        if (string.IsNullOrWhiteSpace(s)) continue;
                        string[] fields = PatientFile.ReadFields(s);
                        bool found;
                        if (mode.SelectedIndex == 0)
                            found = fields[5] == specialization.Text;
                        else if (mode.SelectedIndex == 1)
                            found = DateTime.ParseExact(fields[3], "dd.MM.yyyy",
                                CultureInfo.InvariantCulture).Date == date.Value.Date;
                        else
                            found = fields[5] == specialization.Text && fields[4] == doctor.Text;
                        if (found)
                        {
                            text += s + "\r\n";
                            count++;
                        }
                    }
                }
                if (count == 0) text += "Нет записей";
                result.Text = text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Не удалось прочитать файл");
            }
        }
    }
}
