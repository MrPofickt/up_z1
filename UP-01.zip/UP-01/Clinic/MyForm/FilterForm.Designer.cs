namespace Clinic
{
    partial class FilterForm
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>Освобождает компоненты формы просмотра по условию.</summary>
        /// <param name="disposing">Нужно ли освободить управляемые ресурсы.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Создаёт поля трёх условий отбора и многострочный TextBox результата.</summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FilterForm));
            this.mode = new System.Windows.Forms.ComboBox();
            this.specializationLabel = new System.Windows.Forms.Label();
            this.specialization = new System.Windows.Forms.ComboBox();
            this.dateLabel = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.DateTimePicker();
            this.doctorLabel = new System.Windows.Forms.Label();
            this.doctor = new System.Windows.Forms.ComboBox();
            this.show = new System.Windows.Forms.Button();
            this.result = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // mode
            this.mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mode.Items.AddRange(new object[] {
                "Пациенты по специализации врача", "Пациенты по дате обращения", "Талоны к врачу (специализация и ФИО)" });
            this.mode.Location = new System.Drawing.Point(20, 20);
            this.mode.Name = "mode";
            this.mode.Size = new System.Drawing.Size(740, 28);
            this.mode.TabIndex = 0;
            this.mode.SelectedIndexChanged += new System.EventHandler(this.ModeChanged);
            // specializationLabel
            this.specializationLabel.Location = new System.Drawing.Point(20, 65);
            this.specializationLabel.Name = "specializationLabel";
            this.specializationLabel.Size = new System.Drawing.Size(135, 23);
            this.specializationLabel.Text = "Специализация";
            // specialization
            this.specialization.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.specialization.Location = new System.Drawing.Point(160, 60);
            this.specialization.Name = "specialization";
            this.specialization.Size = new System.Drawing.Size(280, 28);
            this.specialization.TabIndex = 1;
            // dateLabel
            this.dateLabel.Location = new System.Drawing.Point(470, 65);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(50, 23);
            this.dateLabel.Text = "Дата";
            // date
            this.date.CustomFormat = "dd.MM.yyyy";
            this.date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date.Location = new System.Drawing.Point(530, 60);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(230, 28);
            this.date.TabIndex = 2;
            // doctorLabel
            this.doctorLabel.Location = new System.Drawing.Point(20, 107);
            this.doctorLabel.Name = "doctorLabel";
            this.doctorLabel.Size = new System.Drawing.Size(135, 23);
            this.doctorLabel.Text = "ФИО врача";
            // doctor
            this.doctor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.doctor.Location = new System.Drawing.Point(160, 102);
            this.doctor.Name = "doctor";
            this.doctor.Size = new System.Drawing.Size(600, 28);
            this.doctor.TabIndex = 3;
            // show
            this.show.Location = new System.Drawing.Point(800, 20);
            this.show.Name = "show";
            this.show.Size = new System.Drawing.Size(170, 32);
            this.show.TabIndex = 4;
            this.show.Text = "Показать";
            this.show.UseVisualStyleBackColor = true;
            this.show.Click += new System.EventHandler(this.ShowClick);
            // result
            this.result.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.result.Location = new System.Drawing.Point(20, 155);
            this.result.Multiline = true;
            this.result.Name = "result";
            this.result.ReadOnly = true;
            this.result.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.result.Size = new System.Drawing.Size(950, 350);
            this.result.TabIndex = 5;
            this.result.WordWrap = false;
            // FilterForm
            this.AcceptButton = this.show;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1000, 530);
            this.Controls.Add(this.mode);
            this.Controls.Add(this.specializationLabel);
            this.Controls.Add(this.specialization);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.date);
            this.Controls.Add(this.doctorLabel);
            this.Controls.Add(this.doctor);
            this.Controls.Add(this.show);
            this.Controls.Add(this.result);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Name = "FilterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = resources.GetString("$this.Text");
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ComboBox mode;
        private System.Windows.Forms.Label specializationLabel;
        private System.Windows.Forms.ComboBox specialization;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.DateTimePicker date;
        private System.Windows.Forms.Label doctorLabel;
        private System.Windows.Forms.ComboBox doctor;
        private System.Windows.Forms.Button show;
        private System.Windows.Forms.TextBox result;
    }
}
