using System;
using System.Windows.Forms;

namespace Clinic
{
    /// <summary>Точка входа приложения для работы с пациентами поликлиники.</summary>
    internal static class Program
    {
        /// <summary>Проверяет капчу и при успешном вводе открывает главную форму.</summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            using (CaptchaForm captcha = new CaptchaForm())
            {
                if (captcha.ShowDialog() != DialogResult.OK)
                    return;
            }
            Application.Run(new MainForm());
        }
    }
}
