﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Versioning;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace task_1
{
    public partial class CatalogForm : Form
    {
        string fName = @"E:\УП 01.01 C#\ЛР 1\lab_1\Страховщики.txt";
        public CatalogForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Метод для инициализации справочник при загрузке формы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CatalogForm_Load(object sender, EventArgs e)
        {
            textBox1.Text = "";
            StreamReader sr = new StreamReader(fName);
            while (!sr.EndOfStream)
            {
                textBox1.Text += sr.ReadLine() + "\r\n";
            }
            sr.Close();
        }

        /// <summary>
        /// Метод для добавления нового значения в справочник
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox2.Text != "") && (!textBox1.Text.Contains(textBox2.Text)))
            {
                textBox1.Text += textBox2.Text + "\r\n";
            }
        }

        /// <summary>
        /// Метод для удаления значения из справочник
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            if ((textBox2.Text != "") && textBox1.Text.Contains(textBox2.Text))
            {
                int pos = textBox1.Text.IndexOf(textBox2.Text);
                int len = textBox2.TextLength + 2;
                textBox1.Text = textBox1.Text.Remove(pos, len);
            }
        }

        /// <summary>
        /// Метод для сохранения всех значений в справочник
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            File.WriteAllText(fName, textBox1.Text);
        }

        /// <summary>
        /// Метод для закрытия формы редактирования справочника
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
