﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace task_1
{
    public partial class AddRecord : Form
    {
        public AddRecord()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Метод для добавления записи в файл
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text != "")
            && (textBox2.Text != "")
            && (dateTimePicker1.Value != null)
            && (textBox5.Text != "")
            && (textBox6.Text != "")
            && (comboBox1.Text != ""))
            {
                File.AppendAllText(MainForm.fName,
                    //Адреc; Площадь; Количество комнат; Дата продажи; Стоимость дома; Сумма страхового взноса; Фирма-страховщик
                    String.Format($"{textBox1.Text}; {textBox2.Text}; {numericUpDown1.Value}; {dateTimePicker1.Value.ToShortDateString()}; {textBox5.Text}; {textBox6.Text}; {comboBox1.Text}\n"));
                textBox1.Text = "";
                textBox2.Text = "";
                numericUpDown1.Value = 1;
                textBox5.Text = "";
                textBox6.Text = "";
                comboBox1.Text = "";
            }
        }

        /// <summary>
        /// Метод для инициализация словарей при загрузке формы Добавления
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddRecord_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.AddRange(File.ReadAllLines(@"E:\УП 01.01 C#\ЛР 1\lab_1\Страховщики.txt"));
        }

        /// <summary>
        /// Метод для закрытия формы Добавления
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Метод для проверки корректности ввода Площади
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) && (e.KeyChar != 8))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Метод для проверки корректности ввода Стоимости
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) && (e.KeyChar != 8))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Метод для проверки корректности ввода Суммы страхового взноса
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) && (e.KeyChar != 8))
            {
                e.Handled = true;
            }
        }
    }
}
