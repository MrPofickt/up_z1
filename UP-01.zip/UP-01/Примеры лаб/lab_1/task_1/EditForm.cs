﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace task_1
{
    public partial class EditForm : Form
    {
        int count;
        string s;

        public EditForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Собственный метод для извлечения данных из записи в поля для редактирования
        /// </summary>
        /// <param name="s">Запись</param>
        private void ExtractFields(string s)
        {
            string[] fields;
            fields = s.Split(';');
            textBox1.Text = fields[0].Trim();
            textBox2.Text = fields[1].Trim();
            numericUpDown2.Value = int.Parse(fields[2].Trim());
            dateTimePicker1.Value = DateTime.Parse(fields[3].Trim());
            textBox4.Text = fields[4].Trim();
            textBox5.Text = fields[5].Trim();
            comboBox1.Text = fields[6].Trim();
        }

        /// <summary>
        /// Метод для переключения между записями для редактирования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(MainForm.fName);
            for (int i = 1; i <= count; i++)
            {
                s = sr.ReadLine();
                if (i == numericUpDown1.Value)
                {
                    ExtractFields(s);
                    break;
                }
            }
            sr.Close();
        }

        /// <summary>
        /// Метод для инициализации при загрузке формы Редактирования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EditForm_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.AddRange(File.ReadAllLines(@"E:\УП 01.01 C#\ЛР 1\lab_1\Страховщики.txt"));

            count = File.ReadLines(MainForm.fName).Count();
            numericUpDown1.Maximum = count;
            if (count > 0)
            {
                StreamReader sr = new StreamReader(MainForm.fName);
                s = sr.ReadLine();
                ExtractFields(s);
                sr.Close();
            }
        }

        /// <summary>
        /// Метод для сохранения изменённой записи в файл
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text != "")
            && (textBox2.Text != "")
            && (dateTimePicker1.Value != null)
            && (textBox4.Text != "") 
            && (textBox5.Text != "")
            && (comboBox1.Text != ""))
            {
                string fileContent = File.ReadAllText(MainForm.fName);
                string sEdit = String.Format($"{textBox1.Text}; {textBox2.Text}; {numericUpDown2.Value}; {dateTimePicker1.Value.ToShortDateString()}; {textBox4.Text}; {textBox5.Text}; {comboBox1.Text}");
                File.WriteAllText(MainForm.fName, fileContent.Replace(s, sEdit));
            }
        }

        /// <summary>
        /// Метод для проверки корректности ввода Площади
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) && (e.KeyChar != 8))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Метод для проверки корректности ввода Стоимости
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) && (e.KeyChar != 8))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Метод для проверки корректности ввода Суммы страхового взноса
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar < '0') || (e.KeyChar > '9')) && (e.KeyChar != 8))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Метод для закрытия формы Редактирования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();  
        }
    }
}
