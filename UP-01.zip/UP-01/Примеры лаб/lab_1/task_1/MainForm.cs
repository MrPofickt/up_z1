﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace task_1
{
    public partial class MainForm : Form
    {
        static public string fName;
        static public bool viewInterface = false;
        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Метод для создания нового файла
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "text files (*.txt)|*.txt|All files (*.*)|*.*";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (saveFileDialog1.FileName == "")
                {
                    MessageBox.Show("Введите название!");
                }
                else
                {
                    fName = saveFileDialog1.FileName;
                    редактированиеToolStripMenuItem.Enabled = true;
                    просмотрToolStripMenuItem.Enabled = true;
                    очиститьToolStripMenuItem.Enabled = true;
                    File.Create(fName).Close();
                    MessageBox.Show("Файл создан.");
                }
            }
        }

        /// <summary>
        /// Метод для открытия существующего файла
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void выбратьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "text files (*.txt)|*.txt|All files (*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (openFileDialog1.FileName == "")
                {
                    MessageBox.Show("Выберите файл!");
                }
                else
                {
                    fName = openFileDialog1.FileName;
                    редактированиеToolStripMenuItem.Enabled = true;
                    просмотрToolStripMenuItem.Enabled = true;
                    очиститьToolStripMenuItem.Enabled = true;
                    MessageBox.Show("Файл открыт.");
                }
            }
        }

        /// <summary>
        /// Метод для открытия формы Добавления записей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void добавлениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddRecord addRecord = new AddRecord();
            addRecord.ShowDialog();
        }

        /// <summary>
        /// Метод для открытия формы Просмотра всех записей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void всехДанныхToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewInterface = false;
            ViewForm viewForm = new ViewForm();
            viewForm.ShowDialog();
        }

        /// <summary>
        /// Метод для открытия формы Просмотра записей по условию
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void поУсловиюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewInterface = true;
            ViewForm viewForm = new ViewForm();
            viewForm.ShowDialog();
        }

        /// <summary>
        /// Метод для открытия формы Редактирования записей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void редактированиеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            EditForm editForm = new EditForm();
            editForm.ShowDialog();
        }

        /// <summary>
        /// Метод для отчистки открытого файла
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Отчистить файл?", "Подтвердите действие", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                File.Create(fName).Close();
            }
        }

        /// <summary>
        /// Метод для открытия формы редактирования справочника
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void фирмыстраховщикиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CatalogForm catalogForm = new CatalogForm();
            catalogForm.ShowDialog();
        }

        /// <summary>
        /// Метод для закрытия Главной формы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
