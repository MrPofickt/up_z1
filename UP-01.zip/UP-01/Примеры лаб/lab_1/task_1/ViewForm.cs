﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace task_1
{
    public partial class ViewForm : Form
    {
        public ViewForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Метод для закрытия формы Просмотра
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Метод для инициализации при закрузке формы Просмотра
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ViewForm_Load(object sender, EventArgs e)
        {
            label2.Visible         = 
            label3.Visible         = 
            label4.Visible         =
            button1.Visible        = 
            button2.Visible        = 
            button3.Visible        = 
            textBox2.Visible       =
            comboBox1.Visible      = 
            numericUpDown1.Visible = MainForm.viewInterface;
            if (MainForm.viewInterface)
            {
                comboBox1.Items.Clear();
                comboBox1.Items.AddRange(File.ReadAllLines(@"E:\УП 01.01 C#\ЛР 1\lab_1\Страховщики.txt"));
            }
            else
            {
                textBox1.Text = "Адрес, площадь, количество комнат, дата продажи, стоимость, сумма страхового взноса, фирма-страховщик\r\n";
                StreamReader sr = new StreamReader(MainForm.fName);
                int count = 0;
                while (!sr.EndOfStream)
                {
                    textBox1.Text += sr.ReadLine() + "\r\n";
                    count++;
                }
                if (count == 0)
                {
                    textBox1.Text += "Нет записей";
                }
                sr.Close();
            }
        }

        /// <summary>
        /// Метод для вывода записей по Адресу
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Адрес, площадь, количество комнат, дата продажи, стоимость, сумма страхового взноса, фирма-страховщик\r\n";
            StreamReader sr = new StreamReader(MainForm.fName);
            string s;
            int count = 0;
            while (!sr.EndOfStream)
            {
                s = sr.ReadLine();
                if (s.Contains(textBox2.Text) && (textBox2.Text != ""))
                {
                    textBox1.Text += s + "\r\n";
                    count++;
                }
            }
            if (count == 0)
            {
                textBox1.Text += "Нет записей";
            }
            sr.Close();
        }

        /// <summary>
        /// Метод для вывода записей по Фирме-страховщику
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Адрес, площадь, количество комнат, дата продажи, стоимость, сумма страхового взноса, фирма-страховщик\r\n";
            StreamReader sr = new StreamReader(MainForm.fName);
            string s;
            int count = 0;
            while (!sr.EndOfStream)
            {
                s = sr.ReadLine();
                if (s.Contains(comboBox1.Text) && (comboBox1.Text != ""))
                {
                    textBox1.Text += s + "\r\n";
                    count++;
                }
            }
            if (count == 0)
            {
                textBox1.Text += "Нет записей";
            }
            sr.Close();
        }

        /// <summary>
        /// Метод для вывода записейпо Количеству комнат
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Адрес, площадь, количество комнат, дата продажи, стоимость, сумма страхового взноса, фирма-страховщик\r\n";
            StreamReader sr = new StreamReader(MainForm.fName);
            string s;
            string[] fields;
            int count = 0;
            while (!sr.EndOfStream)
            {
                s = sr.ReadLine();
                fields = s.Split(';');
                if (fields[2].Contains(String.Format($"{numericUpDown1.Value}")))
                {
                    textBox1.Text += s + "\r\n";
                    count++;
                }
            }
            if (count == 0)
            {
                textBox1.Text += "Нет записей";
            }
            sr.Close();
        }

        /// <summary>
        /// Метод для отображения на диаграмме данных за год
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(MainForm.fName);
            chart1.Series.Clear();
            Series series1 = new Series("Продажи");

            string s;
            string[] fields;
            int[] month = new int[12];
            while (!sr.EndOfStream)
            {
                s = sr.ReadLine();
                fields = s.Split(';');
                if (DateTime.Parse(fields[3]).Year == numericUpDown2.Value)
                {
                    month[DateTime.Parse(fields[3]).Month - 1]++;
                }
            }
            for (int i = 0; i < 12; i++)
            {
                series1.Points.AddXY((String.Format($"{i+1, 2}.{numericUpDown2.Value}")), month[i]);
            }
            chart1.Series.Add(series1);
        }
    }
}
