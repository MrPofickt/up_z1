﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodCheckMarkaTrue()
        {
            string nomer = "UE43KU6400UXRU";
            bool expected = true;
            bool actual = SamsungLibs.SamsungLib.CheckMarka(nomer);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodCheckMarkaFalse()
        {
            string nomer = "lolkek";
            bool expected = false;
            bool actual = SamsungLibs.SamsungLib.CheckMarka(nomer);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodContinentCorrect()
        {
            string nomer = "UE43KU6400UXRU";
            string expected = "Европа";
            string actual = SamsungLibs.SamsungLib.GetContinent(nomer);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodContinentIncorrect()
        {
            string nomer = "UF43KU6400UXRU";
            string expected = "Неизвестный идентификатор континента";
            string actual = SamsungLibs.SamsungLib.GetContinent(nomer);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodDiagCorrect()
        {
            string nomer = "UE43KU6400UXRU";
            int expected = 43;
            SamsungLibs.SamsungLib monitor = new SamsungLibs.SamsungLib();
            int actual = monitor.GetTVDiag(nomer);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodDiagIncorrect()
        {
            string nomer = "UE9AKU6400UXRU";
            int expected = 0;
            SamsungLibs.SamsungLib monitor = new SamsungLibs.SamsungLib();
            int actual = monitor.GetTVDiag(nomer);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodYearCorrect()
        {
            string nomer = "UE43KU6400UXRU";
            int expected = 2016;
            SamsungLibs.SamsungLib monitor = new SamsungLibs.SamsungLib();
            int actual = monitor.GetTVYear(nomer);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodYearIncorrect()
        {
            string nomer = "UE43BU6400UXRU";
            int expected = 0;
            SamsungLibs.SamsungLib monitor = new SamsungLibs.SamsungLib();
            int actual = monitor.GetTVYear(nomer);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodCountryCorrect()
        {
            string nomer = "UE43KU6400UXRU";
            string expected = "Россия";
            string actual = SamsungLibs.SamsungLib.GetCountry(nomer);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodCountryIncorrect()
        {
            string nomer = "UE43KU6400UXUA";
            string expected = "Неизвестная страна";
            string actual = SamsungLibs.SamsungLib.GetCountry(nomer);

            Assert.AreEqual(expected, actual);
        }
    }
}
