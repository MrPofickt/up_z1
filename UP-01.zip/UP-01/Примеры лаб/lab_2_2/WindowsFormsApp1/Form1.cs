﻿using SamsungLibs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text.ToUpper();
            string nomer = textBox1.Text;
            if (SamsungLib.CheckMarka(nomer))
            {
                SamsungLib monitor = new SamsungLib();
                textBox2.Text = SamsungLib.GetContinent(nomer);
                textBox3.Text = monitor.GetTVYear(nomer).ToString();
                textBox4.Text = monitor.GetTVDiag(nomer).ToString();
                textBox5.Text = SamsungLib.GetCountry(nomer);
            }
            else MessageBox.Show("Введён неверный номер модели");
        }
    }
}
