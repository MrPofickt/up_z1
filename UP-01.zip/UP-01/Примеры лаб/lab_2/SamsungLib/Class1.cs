﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace SamsungLibs
{
    public class SamsungLib
    {
        public static bool CheckMarka(string nomer)
        {
            List<char> tech = new List<char> { 'Q', 'U', 'K' };
            List<char> continent = new List<char> { 'E', 'N', 'A' };
            List<char> year = new List<char> { 'R', 'N', 'M', 'K', 'J', 'H', 'F', 'E' };
            List<char> resolution = new List<char> { 'U', 'S', 'F' };
            List<char> tuner = new List<char> { 'W', 'K', 'U', 'T' };
            if ((nomer.Length == 14)
                && tech.Contains(nomer[0])
                && continent.Contains(nomer[1])
                && Char.IsDigit(nomer[2])
                && Char.IsDigit(nomer[3])
                && year.Contains(nomer[4])
                && resolution.Contains(nomer[5])
                && Char.IsDigit(nomer[6])
                && Char.IsDigit(nomer[7])
                && Char.IsDigit(nomer[8])
                && Char.IsDigit(nomer[9])
                && tuner.Contains(nomer[10])
                && nomer[11] == 'X'
                && Char.IsLetter(nomer[12])
                && Char.IsLetter(nomer[13])) { return true; }
            else return false;

        }

        public static string GetContinent (string nomer)
        {
            string cont;
            switch (nomer[1])
            {
                case 'E': cont = "Европа"; break;
                case 'N': cont = "Северная и Южная Америка"; break;
                case 'A': cont = "Азия, Африка, Австралия"; break;
                default: cont = "Неизвестный идентификатор континента"; break;
            }
            return cont;
        }   

        public int GetTVDiag(string nomer)
        {
            int diag;
            if (int.TryParse(String.Concat(nomer[2], nomer[3]), out diag))
            {
                return diag;
            }

            return 0;
        }
        public int GetTVYear(string nomer)
        {
            int year = 0;
            switch (nomer[4])
            {
                case 'R': year = 2019; break;
                case 'N': year = 2018; break;
                case 'M': year = 2017; break;
                case 'K': year = 2016; break;
                case 'J': year = 2015; break;
                case 'H': year = 2014; break;
                case 'F': year = 2013; break;
                case 'E': year = 2012; break;
            }
            return year;
        }

        public static string GetCountry(string nomer)
        {
            string country;
            switch (String.Concat(nomer[11], nomer[12], nomer[13]))
            {
                case "XRU": country = "Россия"; break;
                case "XCS": country = "Казахстан"; break;
                case "XBT": country = "Балтика"; break;
                case "XXH": country = "Восточная Европа"; break;
                default: country = "Неизвестная страна"; break;
            }
            return country;
        }
    }
}
