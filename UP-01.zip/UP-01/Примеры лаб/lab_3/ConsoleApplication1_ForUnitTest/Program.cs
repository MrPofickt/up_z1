﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1_ForUnitTest
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Имя:");
            string N = Console.ReadLine();
            Console.WriteLine("Возраст:");
            string V_ = Console.ReadLine();
            int V = Convert.ToInt16(V_);
            string x = Otvet(N, V);
            Console.WriteLine(x);
            Console.ReadLine();
        }

        public static string Otvet(string N1, int V1)
        {
            if (V1 >= 18) return N1 + " совершеннолетний";
            else return N1 + " НЕсовершеннолетний";
        }
    }
}
