﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1_zadanie1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Название товара:");
            string N = Console.ReadLine();
            Console.WriteLine("Цена:");
            string P_ = Console.ReadLine();
            int P = Convert.ToInt16(P_);
            Console.WriteLine("Количество:");
            string C_ = Console.ReadLine();
            int C = Convert.ToInt16(C_);
            string x = Cost(N, P, C);
            Console.WriteLine(x);
            Console.ReadLine();

        }

        public static string Cost(string name, int price, int count)
        {
            int cost = price * count;
            if (cost <= 0)
                return "неверная цена или количество";
            else return cost.ToString();
        }
    }
}
