﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Class1_From_Avrotizaciya
    {
        public static string Avtorization(string L, string P)
        {
            if ((L == "ktv") && (P == "555"))
                return "учитель";
            else return "студент";
        }
    }
}
