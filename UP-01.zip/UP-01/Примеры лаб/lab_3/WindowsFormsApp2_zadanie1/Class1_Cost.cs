﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2_zadanie1
{
    public class Class1_Cost
    {
        public static string Cost(string name, int price, int count)
        {
            int cost = price * count;
            if (cost <= 0)
                return "неверная цена или количество";
            else return cost.ToString();
        }
    }
}
