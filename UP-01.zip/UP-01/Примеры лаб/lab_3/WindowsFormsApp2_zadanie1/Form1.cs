﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2_zadanie1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int P = int.Parse(textBox2.Text);
            int C = int.Parse(textBox3.Text);
            textBox4.Text = Class1_Cost.Cost(textBox1.Text, P, C);
        }
    }
}
