﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WindowsFormsApp2_zadanie1;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethodCorrect()
        {
            string N = "Молоко";
            int P = 100;
            int C = 20;
            string expected = "2000";

            string actual = ConsoleApp1_zadanie1.Program.Cost(N, P, C);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodIncorrect()
        {
            string N = "Молоко";
            int P = 0;
            int C = -20;
            string expected = "неверная цена или количество";

            string actual = ConsoleApp1_zadanie1.Program.Cost(N, P, C);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodFormCorrect()
        {
            string N = "Сыр";
            int P = 300;
            int C = 30;
            string expected = "9000";

            string actual = Class1_Cost.Cost(N, P, C);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodFormIncorrect()
        {
            string N = "Сыр";
            int P = -300;
            int C = 30;
            string expected = "неверная цена или количество";

            string actual = Class1_Cost.Cost(N, P, C);

            Assert.AreEqual(expected, actual);
        }
    }
}
