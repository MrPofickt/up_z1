﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodAdult()
        {
            string N1 = "Kомаров";
            int V1 = 24; 
            string expected = "Kомаров совершеннолетний"; 

            string actual = ConsoleApplication1_ForUnitTest.Program.Otvet(N1, V1);
                                                                             
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethodYoung()
        {
            string N1 = "Комаров";
            int V1 = 12;
            string expected = "Комаров НЕсовершеннолетний";

            string actual = ConsoleApplication1_ForUnitTest.Program.Otvet(N1 , V1);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethod1_ktv_555()
        {
            string L1 = "ktv";
            string P1 = "555";
            string expected = "учитель";

            string actual = WindowsFormsApp1.Class1_From_Avrotizaciya.Avtorization(L1 , P1);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestMethod1_ktv_111()
        {
            string L1 = "ktv";
            string P1 = "111";
            string expected = "студент";

            string actual = WindowsFormsApp1.Class1_From_Avrotizaciya.Avtorization(L1, P1);

            Assert.AreEqual(expected, actual);
        }
    }
}
